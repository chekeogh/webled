//We always have to include the library
#include "LedControlMS.h"

/*
 Now we need a LedControl to work with.
 ***** These pin numbers will probably not work with your hardware *****
 pin 12 is connected to the DataIn 
 pin 11 is connected to the CLK 
 pin 10 is connected to LOAD 
 We have only a single MAX72XX.
 */
#define NBR_MTX 2 
LedControl lc=LedControl(12,11,10, NBR_MTX);

String digits= "1234567890";
int digitCounter=0;
/* we always wait a bit between updates of the display */
unsigned long delaytime=300;


void setup() {
  /*
   The MAX72XX is in power-saving mode on startup,
   we have to do a wakeup call
   */
  Serial.begin (9600);
  Serial.println("Setup");
  digitCounter=0;
  for (int i=0; i< NBR_MTX; i++){
    lc.shutdown(i,false);
  /* Set the brightness to a medium values */
    lc.setIntensity(i,8);
  /* and clear the display */
    lc.clearDisplay(i);
  }
}


//  Serial.println("LED0: 0 0");
//  lc.setLed(0,0,0,true);
//  delay(1000);
//  Serial.println("LED0: 0 7");
//  lc.setLed(0,0,7,true);
//  delay(1000);
//  Serial.println("LED0: 7 0");
//  lc.setLed(0,7,0,true);
//  delay(1000);
//  Serial.println("LED0: 7 7");  
//  lc.setLed(0,7,7,true);
//  delay(1000);
//  Serial.println("LED0: 0 0 off");
//  lc.setLed(0,0,0,false);
//  delay(1000);
//  Serial.println("LED0: 0 7 off");
//  lc.setLed(0,0,7,false);
//  delay(1000);
//  Serial.println("LED0: 7 0 off");
//  lc.setLed(0,7,0,false);
//  delay(1000);
//  Serial.println("LED0: 7 7 off");  
//  lc.setLed(0,7,7,false);
//  delay(1000);  
//  //clearAll();
//  
//  lc.setRow(0,1,0x0C);
//  delay(1000);
//  lc.clearDisplay(0);
//  lc.setRow(0,1,0xC0);
//  delay(1000);
//  lc.clearDisplay(0);
//
//  lc.setColumn(0,1,0x0C);
//  delay(1000);
//  lc.clearDisplay(0);
//  lc.setColumn(0,1,0xC0);
//  delay(1000);
//  lc.clearDisplay(0);
//  
//  lc.writeString(0,"Hola Mundo");
//  delay(1000);
//  lc.clearAll();
//  scrollLeft('O');
//  delay(1000);
//  lc.clearAll();
//  scrollRight('O');
//  delay(1000);
//  lc.clearAll();
//
//}


void fanstart() { 

 //lc.writeString(0,"1234567890");
 //lc.displayChar(0,(2);
 //delay(3000);
  //0
   

//lc.setColumn(0,1,(0x0C)/2);

for (int i = 8; i >= 0; i--) {

int fan = pow(2,i);

//1
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
delay(fan);
//2
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
delay(fan);

//3
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
 delay(fan);
//4
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
 delay(fan);
 
//5
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
delay(fan);
//6
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
delay(fan);

//7
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
delay(fan);
//8
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
delay(fan);
//12
}
}


void fanon (){
for (int i = 8; i >= 0; i--) {

//int fan = pow(2,i);

//1
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
//2
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
//3
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
//4
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
//5
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
//6
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
//7
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
//8
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
}
}

void fanoff (){

for (int i = 0; i <= 8; i++) {

int fan = pow(2,i);

//1
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
delay(fan);
//2
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
delay(fan);

//3
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
 delay(fan);
//4
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
 delay(fan);
 
//5
    lc.setColumn(0,7,B00000001);
    lc.setColumn(0,6,B00000010);
    lc.setColumn(0,5,B00000100);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00100000);
    lc.setColumn(0,1,B01000000);
    lc.setColumn(0,0,B10000000);
delay(fan);
//6
    lc.setColumn(0,7,B00001000);
    lc.setColumn(0,6,B00001000);
    lc.setColumn(0,5,B00001000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00010000);
    lc.setColumn(0,1,B00010000);
    lc.setColumn(0,0,B00010000);
delay(fan);

//7
    lc.setColumn(0,7,B10000000);
    lc.setColumn(0,6,B01000000);
    lc.setColumn(0,5,B00100000);
    lc.setColumn(0,4,B00011000);
    lc.setColumn(0,3,B00011000);
    lc.setColumn(0,2,B00000100);
    lc.setColumn(0,1,B00000010);
    lc.setColumn(0,0,B00000001);
delay(fan);
//8
    lc.setColumn(0,7,B00000000);
    lc.setColumn(0,6,B00000000);
    lc.setColumn(0,5,B00000000);
    lc.setColumn(0,4,B11111000);
    lc.setColumn(0,3,B00011111);
    lc.setColumn(0,2,B00000000);
    lc.setColumn(0,1,B00000000);
    lc.setColumn(0,0,B00000000);
delay(fan);
//12
}




 delay(2000); 
}


